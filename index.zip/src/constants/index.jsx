export const navItems = [
  
  {
      label: "About",
      id: "about",
  },
{
        label: "Certifications",
        id: "certifications",
    },
  {
      label: "Skills",
      id: "skills",
  },
  {
      label: "Education",
      id: "education",
  },
  {
      label: "Projects",
      id: "projects",
  },
];